#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"



uint16_t get_speed()
{
    // Implement the speed function
    uint16_t adc = read_adc(CHANNEL4);
    return (adc/10.23);
}


unsigned char get_gear_pos()
{
    //Implement the indicator function
    unsigned char key = read_digital_keypad(STATE_CHANGE);
    static signed char gear;
    
    if(key==SWITCH1)
    {
        if(gear<5)
        gear++;
    }
    else if(key==SWITCH2)
    {
        if(gear>0)
        gear--;
    }
    else if(key==SWITCH3)
    {
        gear=-1;
    }
    
    if(gear==-1)
    {
        return 'R';
    }
    else if(gear==0)
    {
        return 'N';
    }
    else
    {
        return (gear + '0');
    }
}