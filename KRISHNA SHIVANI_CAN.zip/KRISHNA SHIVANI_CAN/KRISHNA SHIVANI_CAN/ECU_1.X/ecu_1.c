/*
 Name : Krishna Shivani S
 * date : 25-03-2026
 * project : CAN automotive dashboard - ECU1 using CAN protocol
 * TITLE : ECU1 speed and gear
 * description :
 * ECU1 is responsible for acquiring vehicle speed and gear position data
 * and transmitting this information over the CAN bus to other ECUs
 * in the automotive dashboard system. The ECU processes input signals,
 * formats CAN messages, and ensures real-time data transmission for
 * accurate dashboard indication.
 */

#define _XTAL_FREQ 20000000
#include <xc.h>
#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"


void speed_convert_ascii(uint16_t speed, unsigned char *arr)
{
    arr[0] = (speed / 100) % 10 + '0';
    arr[1] = (speed / 10) % 10 + '0';
    arr[2] = (speed % 10) + '0';
}
void init_config()
{
    TRISB=0x00;
    PORTB=0x00;
}
int main()
{
    //call the functions
    init_adc();
    init_config();
//    init_uart();
    init_can();
    
    uint16_t msg_id;
    int len=0;
    char arr[5]={0};
    init_digital_keypad();
    while(1)
    { 
        
        unsigned char gear=get_gear_pos();
        
        uint16_t speed=get_speed();
        unsigned char data[4];
        data[3]='\0';
        speed_convert_ascii(speed, data);
        
        can_transmit(GEAR_MSG_ID,&gear,1);
        __delay_ms(50);
        can_transmit(SPEED_MSG_ID,data,3);
        __delay_ms(50);
        
    }
    
}