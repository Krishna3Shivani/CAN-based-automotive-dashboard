/*
 * Name        : Krishna Shivani S
 * Date        : 25-03-2026
 * Project     : CAN Automotive Dashboard - ECU3 Using CAN Protocol
 * Title       : ECU3 Dashboard Display
 *
 * Description :
 * ECU3 functions as the dashboard unit in the CAN automotive system.
 * It receives CAN data from ECU1 and ECU2, including vehicle speed,
 * gear position, RPM, and indicator status. Based on the received
 * messages, ECU3 updates the dashboard displays and indicators
 * accordingly, providing real-time vehicle information to the user.
 */

#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
#include "timer0.h"

static void init_leds() {
    TRISB = 0x00; // Set RB2 as output, RB3 as input, remaining as output
    PORTB = 0x00;
}

static void init_config(void) {
    // Initialize CLCD and CANBUS
    init_clcd();
    init_leds();
    init_can();
    

    // Enable Interrupts
    PEIE = 1;
    GIE = 1;
    init_timer0();
}


void main(void) {
    // Initialize peripherals
    init_config();
    
    clcd_print("SP  GR RPM  IND",LINE1(0));

    /* ECU1 main loop */
    while (1) {
        // Read CAN Bus data and handle it
        process_canbus_data();
    }

    return;
}
